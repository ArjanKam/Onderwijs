SSID     = "Smartlab_studenten"
PASSWORD = "SmartLab"